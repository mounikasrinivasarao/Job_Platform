# Hospital Management System
A full-stack Hospital Management System (HMS) built using the MERN stack (MongoDB, Express.js, React.js, and Node.js) designed to manage hospital operations such as patient records, appointment scheduling, staff management, and more.

# Table of Contents

Project Overview
Features
Technologies Used
Installation
Usage
Folder Structure
Contributing
License
Project Overview

# The Hospital Management System aims to simplify hospital management tasks. This system allows:

Admin users to manage patients, doctors, staff, and appointments.
Doctors to track patient records and schedules.
Patients to manage appointments and view their records.
This project supports features such as login authentication, user roles, and data security.

# Features
User Authentication and Authorization
Secure Login/Logout for Admin, Doctor, and Patient roles.
Role-based access control to different functionalities.

# Admin Portal
Manage Users: Add, view, update, or delete doctors, patients, and staff records.
Manage Appointments: Schedule, reschedule, or cancel appointments.
Department Management: Add, modify, or remove hospital departments.

# Doctor Portal
Appointment Dashboard: View, approve, or reject patient appointments.
Patient Records: Access medical records, update patient details, and add treatment notes.

# Patient Portal
Book Appointments: Schedule appointments with available doctors.
View Medical Records: Access personal health records and previous visits.
Billing Information: Check billing details and payment history.

# Additional Features
Database Security: Ensures data privacy and integrity with encrypted connections and secured routes.
Search & Filter: Easily search and filter through records.

# Technologies Used
Frontend: React.js, JavaScript, CSS
Backend: Node.js, Express.js
Database: MongoDB
Authentication: JSON Web Tokens (JWT)
Image Storage (Optional): Cloudinary or AWS S3 for patient and doctor images.

# Installation
Prerequisites
Node.js
MongoDB (local or remote)
Git
Setup Instructions

# Clone the repository:
git clone https://github.com/mounikasrinivasarao/HMS
cd hospital-management-system

# Install backend dependencies:
cd backend
npm install

# Install frontend dependencies:
cd ../frontend
npm install

# Set up environment variables:
Create a .env file in the backend directory with the following keys:
plaintext
Copy code
MONGO_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
PORT=5000

# Start the backend server:
cd backend
npm start

# Start the frontend server:
cd frontend
npm start

# Access the application:
Backend API: http://localhost:5000/api
Frontend: http://localhost:3000

# Usage
Register as a new admin, doctor, or patient.
Admin users can manage all aspects of the system from the Admin Dashboard.
Doctors can log in to access their appointments and patient records.
Patients can schedule appointments, view their records, and check billing information.

# Folder Structure
hospital-management-system/
├── backend/
│   ├── config/               # Database and environment configurations
│   ├── controllers/          # Business logic for different routes
│   ├── models/               # MongoDB data models
│   ├── routes/               # API routes
│   ├── utils/                # Helper functions
│   └── server.js             # Main server file
│
├── frontend/
│   ├── public/               # Public assets
│   ├── src/
│   │   ├── components/       # Reusable React components
│   │   ├── pages/            # Main application pages (Admin, Doctor, Patient dashboards)
│   │   ├── services/         # API calls and service functions
│   │   ├── App.js            # Root component
│   │   └── index.js          # React entry point
│
└── README.md                 # Project documentation

# Fork the repository.
Create a new feature branch.
Commit your changes and open a pull request.

# License
This project is licensed under the MIT License
